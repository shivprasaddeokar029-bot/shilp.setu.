# ShilpSetu storefront (static website)

A self-contained demo of the ShilpSetu storefront: 77 handmade crafts from 47 artisans across India, each with a
fair-price breakdown, the story of its art form, product details and the artisan's story; a cart; dark mode; and
Shilpi, the helper who finds gifts and explains crafts. No server is needed.

- **Open locally:** double-click `index.html`.
- **Publish on GitHub Pages:** upload this folder's contents to a repository, then Settings → Pages →
  "Deploy from a branch" → `main` / `(root)`. In the full ShilpSetu repository, `.github/workflows/pages.yml`
  publishes this `website/` folder automatically (Settings → Pages → Source: "GitHub Actions").

`data.js` and `images/` are generated from the ShilpSetu API's demo data. Craft photos are from Wikimedia Commons,
credited on each product and on the About page. Artisans, reviews and orders are illustrative.

ShilpSetu · SIH 2026 · PS ID SIH26090 · Team HACKER LOBBY
