// ShilpSetu storefront — a static site (no server): catalogue, product stories, cart and Shilpi the helper.
(() => {
  const PRODUCTS = window.SHILPSETU_PRODUCTS || [];
  const CRAFTS = window.SHILPSETU_CRAFTS || [];
  const byId = Object.fromEntries(PRODUCTS.map((p) => [p.id, p]));
  const app = document.getElementById('app');

  // ---------------------------------------------------------------- helpers
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const rupees = (v) => {
    if (v == null) return '—';
    const s = String(Math.round(v));
    if (s.length <= 3) return `₹${s}`;
    let rest = s.slice(0, -3);
    const parts = [];
    while (rest.length > 2) { parts.unshift(rest.slice(-2)); rest = rest.slice(0, -2); }
    if (rest) parts.unshift(rest);
    return `₹${parts.join(',')},${s.slice(-3)}`;
  };
  const stars = (r) => '★★★★★'.slice(0, Math.round(r)) + '☆☆☆☆☆'.slice(0, 5 - Math.round(r));
  const store = {
    get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  };
  let toastTimer;
  function toast(text) {
    const t = document.getElementById('toast');
    t.textContent = text;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, 2600);
  }

  // Shilpi, the mascot: a little clay pot with a diya flame (animated in CSS).
  const MASCOT = `<svg class="mascot" viewBox="0 0 100 100" aria-hidden="true">
    <defs><linearGradient id="potg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1E4B82"/><stop offset=".5" stop-color="#0F2F57"/><stop offset="1" stop-color="#081528"/></linearGradient>
    <linearGradient id="flameg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF3B0"/><stop offset=".6" stop-color="#FFB347"/><stop offset="1" stop-color="#22D3EE"/></linearGradient></defs>
    <path class="flame" d="M50 3 Q61 15 50 24 Q39 15 50 3Z" fill="url(#flameg)"/>
    <path d="M30 30 C0 42 4 92 50 95 C96 92 100 42 70 30 Z" fill="url(#potg)"/>
    <ellipse cx="50" cy="30" rx="25" ry="5" fill="#0A1A33" stroke="#22D3EE" stroke-width="3.5"/>
    <g class="eyes"><ellipse cx="37" cy="52" rx="8" ry="9.5" fill="#fff"/><ellipse cx="63" cy="52" rx="8" ry="9.5" fill="#fff"/>
    <circle cx="38" cy="53.5" r="4.5" fill="#0A1A33"/><circle cx="64" cy="53.5" r="4.5" fill="#0A1A33"/>
    <circle cx="39.5" cy="51.5" r="1.5" fill="#fff"/><circle cx="65.5" cy="51.5" r="1.5" fill="#fff"/></g>
    <circle cx="26" cy="64" r="4.5" fill="#FF7AA2" opacity=".45"/><circle cx="74" cy="64" r="4.5" fill="#FF7AA2" opacity=".45"/>
    <path d="M42 68 Q50 75 58 68" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
    <g fill="#22D3EE"><circle cx="24" cy="84" r="2.2"/><circle cx="37" cy="86" r="2.2"/><circle cx="50" cy="87" r="2.2"/><circle cx="63" cy="86" r="2.2"/><circle cx="76" cy="84" r="2.2"/></g>
  </svg>`;

  const craftOfDay = () => CRAFTS[Math.floor(Date.now() / 86400000) % CRAFTS.length];
  const categories = [...new Set(PRODUCTS.map((p) => p.category))].sort();

  function search(q) {
    const words = String(q || '').toLowerCase().split(/\s+/).filter(Boolean);
    if (!words.length) return PRODUCTS;
    return PRODUCTS.filter((p) => {
      const hay = [p.title, p.category, p.location, p.artisan.name, p.artisan.craft, p.craft?.name, p.description].join(' ').toLowerCase();
      return words.every((w) => hay.includes(w));
    });
  }

  const card = (p) => `<a class="card" href="#/p/${esc(p.id)}">
      <div class="ph"><img src="${esc(p.image)}" alt="${esc(p.title)}" loading="lazy">${p.artisan.verified ? '<span class="tick" title="Verified artisan">✓</span>' : ''}</div>
      <div class="info"><h3>${esc(p.title)}</h3><div class="loc">${esc(p.location.replace(' • GI-linked cluster', ''))}</div>
      <span class="pill-price">${rupees(p.price)}</span></div></a>`;

  // ---------------------------------------------------------------- cart
  const cart = () => store.get('shilpsetu-cart', {});
  function setCart(c) {
    store.set('shilpsetu-cart', c);
    const n = Object.values(c).reduce((a, b) => a + b, 0);
    const b = document.getElementById('cart-count');
    b.textContent = n;
    b.hidden = n === 0;
  }
  function addToCart(id) {
    const c = cart();
    c[id] = Math.min(20, (c[id] || 0) + 1);
    setCart(c);
    toast(`Added to cart: ${byId[id].title}`);
  }

  // ---------------------------------------------------------------- pages
  let homeState = { q: '', cat: '', sort: 'featured' };

  function renderHome() {
    const c = craftOfDay();
    const hour = new Date().getHours();
    const hello = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
    app.innerHTML = `
      <form class="search" role="search"><input id="q" type="search" placeholder="Search crafts, states, artisans" value="${esc(homeState.q)}" aria-label="Search"></form>
      <div class="chips" id="cats">${['', ...categories].map((cat) => `<button type="button" class="chip${cat === homeState.cat ? ' on' : ''}" data-cat="${esc(cat)}">${esc(cat || 'All crafts')}</button>`).join('')}</div>
      <section class="greet">
        <div class="mascot-slot">${MASCOT}</div>
        <div class="bubble">${hello}! I'm <b>Shilpi</b>. Every price here pays the artisan a fair wage — tap any craft to see how its price is built.</div>
        ${c ? `<div class="cotd"><b>Craft of the day · ${esc(c.name)}</b> <span class="muted">· ${esc(c.region)}</span>
          <p>Did you know? ${esc(c.fact)}</p><button type="button" class="link-btn" data-explore="${esc(c.name.split(' ')[0])}">Explore →</button></div>` : ''}
      </section>
      <div class="row-head"><h2 id="results-title">Fresh from the loom &amp; wheel</h2>
        <select id="sort" aria-label="Sort"><option value="featured">Featured</option><option value="price_asc">Price: low to high</option>
        <option value="price_desc">Price: high to low</option><option value="rating">Top rated</option></select></div>
      <div class="grid" id="grid"></div>`;
    const q = document.getElementById('q');
    const sort = document.getElementById('sort');
    sort.value = homeState.sort;
    const draw = () => {
      let list = search(homeState.q);
      if (homeState.cat) list = list.filter((p) => p.category === homeState.cat);
      if (homeState.sort === 'price_asc') list = [...list].sort((a, b) => a.price - b.price);
      if (homeState.sort === 'price_desc') list = [...list].sort((a, b) => b.price - a.price);
      if (homeState.sort === 'rating') list = [...list].sort((a, b) => b.rating - a.rating || b.reviews - a.reviews);
      document.getElementById('results-title').textContent = homeState.q || homeState.cat
        ? `${list.length} craft${list.length === 1 ? '' : 's'}${homeState.q ? ` for “${homeState.q}”` : ''}${homeState.cat ? ` in ${homeState.cat}` : ''}`
        : 'Fresh from the loom & wheel';
      document.getElementById('grid').innerHTML = list.length ? list.map(card).join('') : '<p class="empty">Nothing found. Try “Madhubani”, “brass” or “Kashmir”.</p>';
    };
    q.addEventListener('input', () => { homeState.q = q.value; draw(); });
    document.querySelector('.search').addEventListener('submit', (e) => e.preventDefault());
    sort.addEventListener('change', () => { homeState.sort = sort.value; draw(); });
    document.getElementById('cats').addEventListener('click', (e) => {
      const b = e.target.closest('[data-cat]');
      if (!b) return;
      homeState.cat = b.dataset.cat;
      document.querySelectorAll('#cats .chip').forEach((x) => x.classList.toggle('on', x === b));
      draw();
    });
    app.querySelector('[data-explore]')?.addEventListener('click', (e) => {
      homeState.q = e.target.dataset.explore;
      q.value = homeState.q;
      draw();
      document.getElementById('results-title').scrollIntoView({ behavior: 'smooth' });
    });
    draw();
  }

  function renderProduct(id) {
    const p = byId[id];
    if (!p) return renderNotFound();
    const a = p.artisan;
    const artisanTotal = p.lines.filter((l) => l.artisan).reduce((s, l) => s + l.amount, 0);
    const more = PRODUCTS.filter((x) => x.artisan.name === a.name && x.id !== p.id);
    const initial = (a.name || '?').trim()[0];
    app.innerHTML = `
      <a class="back" href="#/">← All crafts</a>
      <article class="product">
        <div class="gallery">
          <img src="${esc(p.image)}" alt="${esc(p.title)}">
          ${a.verified ? '<span class="verified">✓ Verified Artisan</span>' : ''}
          ${p.credit ? `<div class="credit">Photo: ${esc(p.credit.author || 'Wikimedia Commons')} · <a href="${esc(p.credit.source)}" target="_blank" rel="noopener">${esc(p.credit.license)}</a></div>` : ''}
        </div>
        <div>
          <h1>${esc(p.title)}</h1>
          <div class="place">📍 ${esc(p.location)}</div>
          <div class="price-row"><span class="price">${rupees(p.price)}</span>${p.compare ? `<span class="compare">${rupees(p.compare)}</span>` : ''}</div>
          ${p.reviews ? `<div><span class="stars" aria-label="${p.rating} out of 5">${stars(p.rating)}</span> <span class="muted">${p.rating} · ${p.reviews} reviews</span></div>` : ''}
          <div class="buy"><button type="button" class="btn" id="add">🛍 Add to cart</button><a class="btn ghost" href="#/cart">View cart</a></div>
          ${p.certificate ? '<div class="muted">🔏 Ships with a signed QR provenance certificate: who made it, where, and how the price was set.</div>' : ''}

          <details class="box" open>
            <summary><h2>How this price is built</h2><span class="share">${rupees(p.share ?? artisanTotal)} of this goes directly to the artisan (${Math.round(p.sharePct ?? 0)}%)</span></summary>
            <table class="lines">${p.lines.map((l) => `<tr class="${l.artisan ? 'to-artisan' : 'other'}"><td>${esc(l.label)}</td><td>${rupees(l.amount)}</td></tr>`).join('')}
            <tr class="total"><td>Price you pay</td><td>${rupees(p.price)}</td></tr></table>
            <p class="muted">Green lines go to the artisan: materials, a fair hourly wage and the craft premium. ShilpSetu keeps a small, visible platform fee.</p>
          </details>

          ${p.description ? `<div class="box"><h2>About this piece</h2><p>${esc(p.description)}</p></div>` : ''}
          ${p.details?.length ? `<div class="box details"><h2>Product details</h2><dl>${p.details.map((d) => `<dt>${esc(d.label)}</dt><dd>${esc(d.value)}</dd>`).join('')}</dl></div>` : ''}
          ${p.craft ? `<section class="story"><div class="kicker">📖 About this art form</div><h2>${esc(p.craft.name)}</h2>
            <div class="pills"><span>📍 ${esc(p.craft.region)}</span>${p.craft.gi ? `<span>🏅 GI · ${esc(p.craft.gi)}</span>` : ''}</div>
            <p class="history">${esc(p.craft.history)}</p><h3>How it's made</h3><p>${esc(p.craft.making)}</p>
            <div class="dyk"><b>Did you know?</b> ${esc(p.craft.fact)}</div></section>` : ''}

          <div class="box"><h2>Meet the artisan</h2>
            <div class="artisan"><div class="avatar">${esc(initial)}</div><div><b>${esc(a.name)}</b>${a.native && a.native !== a.name ? ` · ${esc(a.native)}` : ''}
            <div class="muted">${esc([a.craft, a.years ? `${a.years} years of practice` : ''].filter(Boolean).join(' · '))}</div></div></div>
            <div class="facts"><span>🏠 ${esc(a.place)}</span>${a.cluster ? `<span>👥 ${esc(a.cluster)}</span>` : ''}${a.gi ? `<span>🏅 GI: ${esc(a.gi)}</span>` : ''}</div>
            ${a.story ? `<p class="quote">“${esc(a.story)}”</p>` : ''}</div>
        </div>
      </article>
      ${more.length ? `<div class="row-head"><h2>More from ${esc(a.name)}</h2></div><div class="grid">${more.map(card).join('')}</div>` : ''}`;
    document.getElementById('add').addEventListener('click', () => addToCart(p.id));
  }

  function renderCart() {
    const c = cart();
    const lines = Object.entries(c).filter(([id]) => byId[id]).map(([id, n]) => ({ p: byId[id], n }));
    if (!lines.length) {
      app.innerHTML = `<h1>Your cart</h1><p class="empty">Your cart is empty.</p><a class="btn" href="#/">Browse crafts</a>`;
      return;
    }
    const total = lines.reduce((s, l) => s + l.p.price * l.n, 0);
    const toArtisans = lines.reduce((s, l) => s + (l.p.share ?? 0) * l.n, 0);
    app.innerHTML = `<h1>Your cart</h1><div style="margin-top:14px">${lines.map(({ p, n }) => `
        <div class="cart-line"><img src="${esc(p.image)}" alt=""><div><b>${esc(p.title)}</b><div class="muted">${rupees(p.price)} · ${esc(p.artisan.name)}</div></div>
        <div class="qty"><button type="button" data-dec="${esc(p.id)}" aria-label="One less">−</button><span>${n}</span><button type="button" data-inc="${esc(p.id)}" aria-label="One more">+</button></div></div>`).join('')}</div>
      <div class="box"><div class="price-row"><h2>Total</h2><span class="price">${rupees(total)}</span></div>
        <div class="share">${rupees(toArtisans)} goes to the artisans · shipping included</div></div>
      <form class="box" id="checkout"><h2>Delivery address</h2>
        <div class="field"><label for="n">Name</label><input id="n" required></div>
        <div class="field"><label for="ph">Phone</label><input id="ph" inputmode="tel" required pattern="[0-9+ ]{10,14}"></div>
        <div class="field"><label for="l1">Address</label><input id="l1" required></div>
        <div class="two"><div class="field"><label for="ci">City</label><input id="ci" required></div>
        <div class="field"><label for="pin">PIN code</label><input id="pin" inputmode="numeric" required pattern="[0-9]{6}"></div></div>
        <div class="field"><label for="pay">Payment</label><select id="pay"><option>UPI</option><option>Cash on delivery</option></select></div>
        <button class="btn wide" type="submit">Place order · ${rupees(total)}</button>
        <p class="muted">Demo storefront: no payment is taken and nothing is shipped.</p></form>`;
    app.querySelectorAll('[data-inc],[data-dec]').forEach((b) => b.addEventListener('click', () => {
      const cc = cart();
      const id = b.dataset.inc || b.dataset.dec;
      cc[id] = (cc[id] || 0) + (b.dataset.inc ? 1 : -1);
      if (cc[id] <= 0) delete cc[id];
      setCart(cc);
      renderCart();
    }));
    document.getElementById('checkout').addEventListener('submit', (e) => {
      e.preventDefault();
      setCart({});
      app.innerHTML = `<div class="done-box"><div class="mascot-slot" style="width:120px;height:120px;margin:0 auto">${MASCOT}</div>
        <h1>Thank you!</h1><p>Your order is placed (demo). ${rupees(toArtisans)} of it goes straight to the artisans who made your crafts.</p>
        <a class="btn" href="#/">Keep exploring</a></div>`;
    });
  }

  function renderAbout() {
    const credited = PRODUCTS.filter((p) => p.credit);
    app.innerHTML = `<div class="about"><h1>About ShilpSetu</h1>
      <p><b>From handmade to headline-worthy — every craft, always in market.</b> ShilpSetu is a voice-first app that turns one photo and one
      spoken sentence into a fair-priced, trust-verified listing for India's artisans — with no typing, no middleman and no English required.</p>
      <p>This website is a static demo of the ShilpSetu storefront. The full platform (Android app, artisan voice listing, kiosk mode,
      admin dashboard, ONDC publishing and the fair-price engine) lives in the project repository.</p>
      <ul><li><b>Fair price, shown:</b> every product explains where each rupee goes, and the artisan's hourly wage floor is never cut.</li>
      <li><b>Proof of origin:</b> each product ships with a signed QR certificate.</li>
      <li><b>Every art form:</b> ${PRODUCTS.length} crafts from ${new Set(PRODUCTS.map((p) => p.artisan.name)).size} artisans across India.</li></ul>
      <p class="muted">Smart India Hackathon 2026 · Problem Statement SIH26090 · Ministry of Social Justice &amp; Empowerment · Team HACKER LOBBY.
      Artisans, reviews and orders on this site are illustrative.</p>
      <h2 style="margin-top:22px">Photo credits</h2><p class="muted">Real craft photos from Wikimedia Commons, used under their licences.</p>
      <ol class="credits">${credited.map((p) => `<li>${esc(p.title)} — ${esc(p.credit.author || 'unknown')} · <a href="${esc(p.credit.source)}" target="_blank" rel="noopener">${esc(p.credit.license)}</a></li>`).join('')}</ol></div>`;
  }

  function renderNotFound() {
    app.innerHTML = '<p class="empty">That page does not exist.</p><a class="btn" href="#/">Go to the store</a>';
  }

  function route() {
    const [, page, id] = (location.hash || '#/').split('/');
    if (page === 'p') renderProduct(decodeURIComponent(id || ''));
    else if (page === 'cart') renderCart();
    else if (page === 'about') renderAbout();
    else renderHome();
    window.scrollTo(0, 0);
    app.focus({ preventScroll: true });
  }

  // ---------------------------------------------------------------- Shilpi chat (rule-based, offline)
  const SUGGEST = ['Gifts under ₹500', 'Tell me about Madhubani', 'What is a GI tag?', 'Why this price?', 'Cheapest crafts'];
  const craftMatch = (m) => {
    const low = m.toLowerCase();
    return CRAFTS.find((c) => low.includes(c.key.replace(/_/g, ' ')) || low.includes(c.name.toLowerCase().split(' ')[0]));
  };
  const has = (m, ...w) => w.some((x) => new RegExp(`\\b${x}`, 'i').test(m));

  function answer(m) {
    const num = Number((m.match(/\d[\d,]*/) || [''])[0].replace(/,/g, '')) || null;
    const craft = craftMatch(m);
    if (/^(hi|hello|hey|namaste)\b/i.test(m.trim()) && m.split(/\s+/).length <= 3) {
      return { text: "Namaste! I'm Shilpi. Ask me for gifts under any budget, or the story behind any craft." };
    }
    if (has(m, 'thank')) return { text: 'Happy to help! Come back any time.' };
    if (craft && has(m, 'about', 'history', 'what', 'tell', 'story', 'made', 'how')) {
      return { text: `${craft.name} (${craft.region}). ${craft.history} Did you know? ${craft.fact}`,
        cards: search(craft.name.split(' ')[0]).slice(0, 6) };
    }
    if (has(m, 'gi tag', 'gi\\b', 'geographical')) {
      return { text: "A GI (Geographical Indication) tag is a government mark that a craft comes from its home region and is made the traditional way — like Madhubani paintings from Bihar or Kashmir Pashmina. Look for 🏅 GI on a product page." };
    }
    if (has(m, 'certificate', 'qr', 'genuine', 'authentic', 'fake')) {
      return { text: 'Every product ships with a signed QR certificate. Scanning it shows who made the piece, where, and that nobody has changed the details.' };
    }
    if (has(m, 'why', 'price', 'expensive', 'costly', 'fair')) {
      return { text: "Prices start from the artisan's real costs — materials, hours at a fair wage, tools, packing and delivery — plus a small 4% platform fee. Open “How this price is built” on any product to see every rupee." };
    }
    if (has(m, 'cheap', 'afford', 'budget', 'low price') || (num && has(m, 'under', 'below', 'within', 'less', 'gift'))) {
      const limit = num || 400;
      const list = PRODUCTS.filter((p) => p.price <= limit).sort((a, b) => b.rating - a.rating || a.price - b.price).slice(0, 6);
      return list.length
        ? { text: `Here are handmade picks under ${rupees(limit)} — every one pays the artisan a fair wage.`, cards: list }
        : { text: `Nothing under ${rupees(limit)} right now. These are the most affordable pieces:`, cards: [...PRODUCTS].sort((a, b) => a.price - b.price).slice(0, 6) };
    }
    if (has(m, 'gift')) {
      return { text: 'Lovely gift ideas, all under ₹500:', cards: PRODUCTS.filter((p) => p.price <= 500).slice(0, 6) };
    }
    const found = search(m.replace(/\b(show|me|find|i|want|looking|for|some|a|an|the|please)\b/gi, ' '));
    if (craft || (found.length && found.length < PRODUCTS.length)) {
      return { text: `I found ${found.length} craft${found.length === 1 ? '' : 's'} for “${m}”.`, cards: found.slice(0, 6) };
    }
    return { text: 'I can find gifts for any budget, tell you the story of a craft, or explain a price. Try one of these:' };
  }

  const chat = document.getElementById('chat');
  const log = document.getElementById('chat-log');
  function say(who, text, cards) {
    const d = document.createElement('div');
    d.className = `msg ${who}`;
    d.textContent = text;
    log.appendChild(d);
    if (cards?.length) {
      const row = document.createElement('div');
      row.className = 'msg-cards';
      row.innerHTML = cards.map(card).join('');
      row.addEventListener('click', (e) => { if (e.target.closest('a')) chat.hidden = true; });
      log.appendChild(row);
    }
    log.scrollTop = log.scrollHeight;
  }
  function openChat() {
    chat.hidden = false;
    if (!log.childElementCount) {
      const c = craftOfDay();
      say('bot', `Namaste! I'm Shilpi, your ShilpSetu helper.${c ? ` Today's craft is ${c.name} from ${c.region}.` : ''} What are you looking for?`);
    }
    document.getElementById('chat-input').focus();
  }
  document.getElementById('shilpi-fab').innerHTML = MASCOT;
  document.getElementById('chat-mascot').innerHTML = MASCOT;
  document.getElementById('shilpi-fab').addEventListener('click', () => (chat.hidden ? openChat() : (chat.hidden = true)));
  document.getElementById('chat-close').addEventListener('click', () => { chat.hidden = true; });
  document.getElementById('chat-chips').innerHTML = SUGGEST.map((s) => `<button type="button">${esc(s)}</button>`).join('');
  const ask = (text) => {
    if (!text.trim()) return;
    say('me', text);
    const r = answer(text);
    setTimeout(() => say('bot', r.text, r.cards), 250);
  };
  document.getElementById('chat-chips').addEventListener('click', (e) => { if (e.target.tagName === 'BUTTON') ask(e.target.textContent); });
  document.getElementById('chat-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const i = document.getElementById('chat-input');
    ask(i.value);
    i.value = '';
  });

  // ---------------------------------------------------------------- theme + splash + start
  const themeBtn = document.getElementById('theme-toggle');
  const isDark = () => (document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')) === 'dark';
  const syncThemeBtn = () => { themeBtn.textContent = isDark() ? '☀' : '☾'; themeBtn.title = isDark() ? 'Light mode' : 'Dark mode'; };
  themeBtn.addEventListener('click', () => {
    const next = isDark() ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('shilpsetu-theme', next); } catch {}
    syncThemeBtn();
  });
  syncThemeBtn();

  const splash = document.getElementById('splash');
  const hideSplash = () => splash.classList.add('done');
  splash.addEventListener('click', hideSplash);
  splash.addEventListener('animationend', (e) => { if (e.animationName === 'splash-out') hideSplash(); });
  try {
    if (sessionStorage.getItem('shilpsetu-splash')) hideSplash(); // once per visit
    sessionStorage.setItem('shilpsetu-splash', '1');
  } catch {}

  setCart(cart());
  window.addEventListener('hashchange', route);
  route();
})();
